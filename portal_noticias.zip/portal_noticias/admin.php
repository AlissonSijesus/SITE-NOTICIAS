

<?php


session_start(); // Ativa sessão para usar o token

// Ativa exibição de erros (somente em desenvolvimento)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexão com o banco de dados
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "portal_noticias";

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Gera um novo token para o formulário se não existir
if (empty($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}

// Publicar nova notícia
if (
    $_SERVER["REQUEST_METHOD"] === "POST" &&
    isset($_POST['form_token']) &&
    isset($_SESSION['form_token']) &&
    $_POST['form_token'] === $_SESSION['form_token']
) {
    unset($_SESSION['form_token']); // Evita reenvio duplicado

    // Verifica se os campos obrigatórios foram enviados
    if (!empty($_POST['titulo']) && !empty($_POST['resumo']) && !empty($_POST['categoria']) && isset($_FILES['imagem'])) {
        $titulo = $conn->real_escape_string($_POST['titulo']);
        $resumo = $conn->real_escape_string($_POST['resumo']);
        $categoria = $conn->real_escape_string($_POST['categoria']);

        if (is_uploaded_file($_FILES['imagem']['tmp_name'])) {
            $extensao = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
            $nomeUnico = uniqid('img_', true) . '.' . $extensao;
            $caminhoImagem = 'uploads/' . $nomeUnico;

            if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminhoImagem)) {
                $sql = "INSERT INTO noticias (titulo, resumo, categoria, imagem) 
                        VALUES ('$titulo', '$resumo', '$categoria', '$caminhoImagem')";
                
                if ($conn->query($sql) === TRUE) {
                    header("Location: admin.php?msg=publicada");
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>Erro ao publicar notícia: " . $conn->error . "</div>";
                }
            } else {
                echo "<div class='alert alert-warning'>Erro ao fazer upload da imagem.</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>Imagem inválida ou não enviada.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Todos os campos são obrigatórios.</div>";
    }
} else if ($_SERVER["REQUEST_METHOD"] === "POST") {
    echo "<div class='alert alert-danger'>Formulário já enviado ou token inválido.</div>";
}

// Excluir notícia
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    $sql = "DELETE FROM noticias WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        header("Location: admin.php?msg=excluida");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Erro ao excluir notícia: " . $conn->error . "</div>";
    }
}

// Buscar todas as notícias
$sql_noticias = "SELECT * FROM noticias ORDER BY data_criacao DESC";
$result_noticias = $conn->query($sql_noticias);

// Buscar frase da barra de notícias
$sql = "SELECT valor FROM configuracoes WHERE nome = 'barra_noticias'";
$result = $conn->query($sql);
$barra_noticias = $result->fetch_assoc()['valor'] ?? '';
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Portal de Notícias - Admin</title>
  <link rel="stylesheet" href="CSS/admin.css">
  <script src="https://cdn.tiny.cloud/1/1ochfmr2t6z0ajux03loumtpm4nane8yclfrykh2viw1urbq/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

  <script>
  tinymce.init({
    selector: '#resumo',
    plugins: 'image link lists code',
    toolbar: 'undo redo | bold italic underline | image link | bullist numlist | code',
    height: 250,
    images_upload_url: 'upload_tiny.php',
    automatic_uploads: true,
    file_picker_types: 'image',
    image_dimensions: true,
    image_caption: true,

    file_picker_callback: function(cb, value, meta) {
      if (meta.filetype === 'image') {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
        input.onchange = function() {
          const file = this.files[0];
          const formData = new FormData();
          formData.append('file', file);
          fetch('upload_tiny.php', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => cb(data.location));
        };
        input.click();
      }
    }
  });

  document.getElementById('formNoticia').addEventListener('submit', function(e) {
    tinymce.triggerSave(); // Garante que o conteúdo vai pro textarea
    const resumo = tinymce.get("resumo").getContent({ format: "text" }).trim();
    if (resumo === "") {
      alert("Por favor, preencha o campo Resumo.");
      e.preventDefault();
    }
  });

  document.getElementById("sidebarCollapse").addEventListener("click", function() {
  const sidebar = document.getElementById("sidebar");
  const pageContent = document.getElementById("page-content-wrapper");

  sidebar.style.display = sidebar.style.display === "none" ? "block" : "none";
  pageContent.style.marginLeft = sidebar.style.display === "none" ? "0" : "250px";
});

</script>


</head>
<body>
<?php if (isset($_GET['msg'])): ?>
  <div class="container mt-3">
    <?php
      switch ($_GET['msg']) {
        case 'publicada':
          echo "<div class='alert alert-success'>✅ Notícia publicada com sucesso!</div>";
          break;
        case 'excluida':
          echo "<div class='alert alert-warning'>🗑️ Notícia excluída com sucesso!</div>";
          break;
        case 'erro_publicar':
          echo "<div class='alert alert-danger'>❌ Erro ao publicar a notícia.</div>";
          break;
        case 'erro_upload':
          echo "<div class='alert alert-danger'>⚠️ Erro ao enviar a imagem.</div>";
          break;
        case 'barra_atualizada':
          echo "<div class='alert alert-success'>📢 Barra de notícias atualizada com sucesso!</div>";
          break;
        case 'erro_barra':
          echo "<div class='alert alert-danger'>❌ Erro ao atualizar a barra de notícias.</div>";
          break;
      }
    ?>
  </div>
<?php endif; ?>

<!-- Adicione este botão no topo do seu header -->
<button id="sidebarCollapse" class="btn btn-primary">
  ☰ Menu
</button>

  <!-- Menu Lateral (Sidebar) -->
  <div class="d-flex" id="wrapper">
    <div class="bg-dark text-white" id="sidebar">
      <div class="sidebar-heading text-center py-3">
        <h4>administre seu protal de noticias</h4>
      </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-dark text-white">HOME</a>
        <a href="admin.php#lista-noticias" class="list-group-item ...">Gerenciar Notícias</a>
        <a href="admin.php#gerenciar-categorias" class="list-group-item list-group-item-action bg-dark text-white">Gerenciar Categorias</a>
        <a href="admin.php#tags-populares" class="list-group-item list-group-item-action bg-dark text-white">Tags Populares</a>
      </div>
    </div>

    <div id="page-content-wrapper" class="container-fluid">
      <header class="bg-dark text-white py-3">
        <div class="container d-flex justify-content-between align-items-center">
          <h1 class="h3 m-0">📰 ADMIN</h1>
        </div>
      </header>

      <section id="lista-noticias" class="my-4">
  <h2>Postar Nova Notícia</h2>
  <form id="formNoticia" action="admin.php" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="form_token" value="<?= $_SESSION['form_token'] ?>">
 
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="titulo">Título</label>
    <input type="text" name="titulo" id="titulo" class="form-control" required>
  </div>
  <div class="form-group col-md-6">
    <label for="categoria">Categoria</label>
    <select name="categoria" id="categoria" class="form-control" required>
      <option value="Política">Política</option>
      <option value="Esportes">Esportes</option>
      <option value="Tecnologia">Tecnologia</option>
      <option value="Economia">Economia</option>
    </select>
  </div>
</div>

<div class="form-group">
  <label for="resumo">Resumo</label>
  <textarea name="resumo" id="resumo" class="form-control" rows="3" ></textarea>
</div>
<div class="form-group">
  <label for="imagem">Imagem</label>
  <input type="file" name="imagem" id="imagem" class="form-control" required>
</div>
<button type="submit" name="submit" class="btn btn-primary">Publicar Notícia</button>
 </form>
</section>



        <div class="container mt-4">
        <h2>Administração - Alterar Barra de Notícias</h2>

        <!-- Formulário para alterar a frase -->
        <form method="POST" action="#barra-noticias">
    <div class="form-group">
      <label for="nova_barra">Texto da barra de notícias:</label>
      <textarea name="nova_barra" id="nova_barra" rows="3" class="form-control"><?= htmlspecialchars($frase_atual) ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Salvar</button>

    <!-- Formulário para editar as Tags Populares -->
<section id="editar-tags" class="form-section mt-5">
  

  <?php
  // Busca tags atuais
  // $tags_populares = '';
  // $sql_tags = "SELECT valor FROM configuracoes WHERE nome = 'tags_populares'";
  // $res_tags = $conn->query($sql_tags);
  // if ($res_tags && $res_tags->num_rows > 0) {
  //     $linha_tags = $res_tags->fetch_assoc();
  //     $tags_populares = $linha_tags['valor'];
  // }

  // // Se o formulário for enviado
  // if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["tags_populares"])) {
  //     $novas_tags = $conn->real_escape_string($_POST["tags_populares"]);
  //     $sql_update_tags = "UPDATE configuracoes SET valor = '$novas_tags' WHERE nome = 'tags_populares'";
  //     if ($conn->query($sql_update_tags)) {
  //         echo "<div class='alert alert-success'>Tags atualizadas com sucesso!</div>";
  //         $tags_populares = $novas_tags;
  //     } else {
  //         echo "<div class='alert alert-danger'>Erro ao atualizar as tags: " . $conn->error . "</div>";
  //     }
  // }

 
  ?>

  <!-- <form method="post">
    <div class="form-group">
      <label for="tags_populares">Digite as tags separadas por vírgula:</label>
      <input type="text" name="tags_populares" class="form-control" value="<?= htmlspecialchars($tags_populares) ?>" placeholder="#Exemplo1, #Exemplo2, #Exemplo3">
    </div>
    <button type="submit" class="btn btn-primary">Salvar Tags</button>
  </form> -->
</section>

  </form>
    </div>
      </section>

      <!-- Gerenciar Notícias -->
      <section id="gerenciar-noticias" class="my-4">
        <h2>Gerenciar Notícias</h2>
         

      <?php
        if ($result_noticias->num_rows > 0) {
            while($row = $result_noticias->fetch_assoc()) {
                echo "<div class='card mb-3'>";
                echo "<img src='" . $row['imagem'] . "' class='card-img-top' alt='Notícia'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . $row['titulo'] . "</h5>";
                // echo "<p class='card-text'>" . $row['resumo'] . "</p>";
                echo "<a href='edit.php?id=" . $row['id'] . "' class='btn btn-warning'>Editar</a>";
                echo "<a href='admin.php?id=" . $row['id'] . "' class='btn btn-danger'>Excluir</a>";
                echo "</div>";
                echo "</div>";
                // echo nl2br(htmlspecialchars($row['resumo']));
                // echo $row['conteudo'];


            }
        } else {
            echo "<p>Nenhuma notícia encontrada.</p>";
        }

        // Carrega a frase atual
  $frase_atual = '';
  $sql_barra = "SELECT valor FROM configuracoes WHERE nome = 'barra_noticias'";
  $res_barra = $conn->query($sql_barra);
  if ($res_barra && $res_barra->num_rows > 0) {
      $linha = $res_barra->fetch_assoc();
      $frase_atual = $linha['valor'];
  }

  // Atualiza se o formulário for enviado
  if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nova_barra"])) {
      $nova_frase = $conn->real_escape_string($_POST["nova_barra"]);
      $sql_update = "UPDATE configuracoes SET valor = '$nova_frase' WHERE nome = 'barra_noticias'";
      if ($conn->query($sql_update)) {
          echo "<div class='alert alert-success'>Frase atualizada com sucesso!</div>";
          $frase_atual = $nova_frase;
      } else {
          echo "<div class='alert alert-danger'>Erro ao atualizar: " . $conn->error . "</div>";
      }
  }
    // Carrega a frase atual
  $frase_atual = '';
  $sql_barra = "SELECT valor FROM configuracoes WHERE nome = 'barra_noticias'";
  $res_barra = $conn->query($sql_barra);
  if ($res_barra && $res_barra->num_rows > 0) {
      $linha = $res_barra->fetch_assoc();
      $frase_atual = $linha['valor'];
  }

  // Atualiza se o formulário for enviado
  if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nova_barra"])) {
      $nova_frase = $conn->real_escape_string($_POST["nova_barra"]);
      $sql_update = "UPDATE configuracoes SET valor = '$nova_frase' WHERE nome = 'barra_noticias'";
      if ($conn->query($sql_update)) {
          echo "<div class='alert alert-success'>Frase atualizada com sucesso!</div>";
          $frase_atual = $nova_frase;
      } else {
          echo "<div class='alert alert-danger'>Erro ao atualizar: " . $conn->error . "</div>";
      }
  }
        ?>
        </section>
        

      <!-- Rodapé -->
      <footer class="bg-dark text-white text-center py-3">
        <p class="mb-0">© 2025 Portal de Notícias — Todos os direitos reservados</p>
        <div class="mt-2">
          <a href="#" class="text-white mx-2">Facebook</a>
          <a href="#" class="text-white mx-2">Twitter</a>
          <a href="#" class="text-white mx-2">Instagram</a>
        </div>
      </footer>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/script.js"></script>
</body>
</html>
