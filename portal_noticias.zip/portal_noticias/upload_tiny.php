<?php
$targetDir = "uploads/";
$targetFile = $targetDir . basename($_FILES["file"]["name"]);

$response = [];

if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
    $response = ['location' => $targetFile]; // retorno esperado pelo TinyMCE
} else {
    http_response_code(400);
    $response = ['error' => 'Erro ao fazer upload.'];
}

echo json_encode($response);
?>
