<?php
// Conexão com o banco de dados
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "portal_noticias";

// Conecta ao banco de dados
$conn = new mysqli($host, $usuario, $senha, $banco);

// Verifica a conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Consulta as notícias da categoria 'Política' e ordena por data de criação decrescente
$sql = "SELECT * FROM noticias WHERE categoria = 'Política' ORDER BY data_criacao DESC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Política - Portal de Notícias</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
  <link rel="stylesheet" href="post/style.css" />
</head>
<body>

  <!-- Menu Lateral (Sidebar) -->
  <div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-dark text-white" id="sidebar">
      <div class="sidebar-heading text-center py-3">
        <h4>Portal de Notícias</h4>
      </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-dark text-white">HOME</a>
      </div>
    </div>

    <!-- Conteúdo Principal -->
    <div id="page-content-wrapper" class="container-fluid">
      <!-- Header -->
      <header class="bg-dark text-white py-3">
        <div class="container d-flex justify-content-between align-items-center">
          <h1 class="h3 m-0">📰 Portal de Notícias - Política</h1>
        </div>
      </header>

      <!-- Notícias de Política -->
      <main class="container my-4">
        <div class="row">
          <section class="col-md-8">
            <h2 class="mb-4">Notícias de Política</h2>            
            <?php
            // Verifica se há notícias
            if ($result->num_rows > 0) {
                // Exibe as notícias
                while($row = $result->fetch_assoc()) {
                    echo '<div class="card mb-3">';
                    echo '<img src="' . $row['imagem'] . '" class="card-img-top" alt="Notícia">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . $row['titulo'] . '</h5>';
                    echo '<p class="card-text">' . $row['resumo'] . '</p>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>Nenhuma notícia encontrada.</p>';
            }

            // Fecha a conexão
            $conn->close();
            ?>
          </section>

          <!-- Sidebar -->
          <aside class="col-md-4">
            <!-- Você pode repetir o mesmo conteúdo da sidebar do index aqui, ou personalizar -->
          </aside>
        </div>
      </main>

      <!-- Rodapé -->
      <footer class="bg-dark text-white text-center py-3">
        <p class="mb-0">© 2025 Portal de Notícias — Todos os direitos reservados</p>
      </footer>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
