// // Função para carregar as notícias
// function carregarNoticias() {
//     const noticias = JSON.parse(localStorage.getItem('noticias')) || [];
//     const container = document.getElementById('noticias-container');
//     container.innerHTML = ''; // Limpar container antes de renderizar
  
//     noticias.forEach(noticia => {
//       const noticiaElement = document.createElement('div');
//       noticiaElement.classList.add('col-md-4', 'mb-4');
//       noticiaElement.innerHTML = `
//         <div class="card">
//           <img src="${noticia.imagem || 'https://via.placeholder.com/750x300'}" class="card-img-top" alt="${noticia.titulo}">
//           <div class="card-body">
//             <h5 class="card-title">${noticia.titulo}</h5>
//             <p class="card-text">${noticia.conteudo}</p>
//             <p class="text-muted">Categoria: ${noticia.categoria}</p>
//             <p class="text-muted">Tags: ${noticia.tags}</p>
//           </div>
//         </div>
//       `;
//       container.appendChild(noticiaElement);
//     });
//   }
  
//   // // Função para salvar a notícia
//   // document.getElementById('formNoticia').addEventListener('submit', function (e) {
//   //   e.preventDefault();
    
//   //   const titulo = document.getElementById('titulo').value;
//   //   const conteudo = document.getElementById('conteudo').value;
//   //   const imagem = document.getElementById('imagem').value;
//   //   const categoria = document.getElementById('categoria').value;
//   //   const tags = document.getElementById('tags').value;
  
//   //   const noticia = {
//   //     titulo,
//   //     conteudo,
//   //     imagem,
//   //     categoria,
//   //     tags
//   //   };
  
//   //   // Recuperar notícias do localStorage
//   //   let noticias = JSON.parse(localStorage.getItem('noticias')) || [];
//   //   noticias.push(noticia);
//   //   localStorage.setItem('noticias', JSON.stringify(noticias));
  
//   // //   // Limpar o formulário e recarregar as notícias
//   // //   document.getElementById('formNoticia').reset();
//   // //   carregarNoticias();
//   // // });
  
//   // // Carregar notícias ao inicializar a página admin
//    document.addEventListener('DOMContentLoaded', carregarNoticias);
  

// Função para carregar as notícias do localStorage (opcional, apenas visual)
function carregarNoticias() {
  const noticias = JSON.parse(localStorage.getItem('noticias')) || [];
  const container = document.getElementById('noticias-container');

  if (container) {
    container.innerHTML = ''; // Limpar container antes de renderizar

    noticias.forEach(noticia => {
      const noticiaElement = document.createElement('div');
      noticiaElement.classList.add('col-md-4', 'mb-4');
      noticiaElement.innerHTML = `
        <div class="card">
          <img src="${noticia.imagem || 'https://via.placeholder.com/750x300'}" class="card-img-top" alt="${noticia.titulo}">
          <div class="card-body">
            <h5 class="card-title">${noticia.titulo}</h5>
            <p class="card-text">${noticia.conteudo}</p>
            <p class="text-muted">Categoria: ${noticia.categoria}</p>
            <p class="text-muted">Tags: ${noticia.tags}</p>
          </div>
        </div>
      `;
      container.appendChild(noticiaElement);
    });
  }
}

// Apenas carrega as notícias (se estiver usando localStorage como histórico visual)
document.addEventListener('DOMContentLoaded', carregarNoticias);
