<?php
$servername = "";  // Endereço do banco de dados
$username = "seu_usuario";         // Nome de usuário do banco
$password = "sua_senha";           // Senha do banco de dados
$dbname = "seu_banco";             // Nome do banco de dados

// Conexão com o banco
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificação de erro
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>
