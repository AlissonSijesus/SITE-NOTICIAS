<?php
// Conectar ao banco
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "portal_noticias";

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Verificar se recebeu ID
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    // Deletar a notícia
    $sql = "DELETE FROM noticias WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: admin.php?msg=noticia_excluida");
        exit();
    } else {
        echo "Erro ao excluir: " . $conn->error;
    }
} else {
    echo "ID inválido.";
}

$conn->close();
?>
