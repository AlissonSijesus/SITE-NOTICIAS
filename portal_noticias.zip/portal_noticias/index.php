<?php
session_start();

// Gerar um token único
if (empty($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
// Conexão com o banco de dados
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "portal_noticias";

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Buscar as últimas notícias
$sql = "SELECT * FROM noticias ORDER BY data_criacao DESC LIMIT 5";
$result = $conn->query($sql);

// Buscar a frase da barra de notícias
$barra_noticias = "Últimas atualizações indisponíveis no momento.";
$sql_barra = "SELECT valor FROM configuracoes WHERE nome = 'barra_noticias'";
$res_barra = $conn->query($sql_barra);
if ($res_barra && $res_barra->num_rows > 0) {
    $linha = $res_barra->fetch_assoc();
    $barra_noticias = $linha['valor'];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Portal de Notícias</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
  <link rel="stylesheet" href="CSS/style.css" />
</head>
<body>

<div class="d-flex" id="wrapper">
  <div id="page-content-wrapper" class="container-fluid">

    <!-- Header -->
    <header class="bg-dark text-white py-3">
      <div class="container d-flex justify-content-between align-items-center">
        <h1 class="h3 m-0">📰 Portal de Notícias</h1>
        <nav>
          <a href="#" class="text-white mx-2">Início</a>
          <a href="#" class="text-white mx-2">Política</a>
          <a href="#" class="text-white mx-2">Esportes</a>
          <a href="#" class="text-white mx-2">Tecnologia</a>
        </nav>
      </div>
    </header>

    <!-- Barra de notícias -->
    <section class="news-ticker bg-light py-2 border-bottom">
      <div class="container">
        <marquee behavior="scroll" direction="left" scrollamount="5">
          <?= htmlspecialchars($barra_noticias) ?>
        </marquee>
      </div>
    </section>

    <!-- Conteúdo principal -->
    <main class="container my-4">
      <div class="row">
        <!-- Notícias principais -->
        <section class="col-lg-8 col-12 mb-4">
          <h2 class="mb-4">Últimas Notícias</h2>

          <?php
         
// // Buscar tags populares
// $sql_tags = "SELECT nome FROM tags_populares";
// $res_tags = $conn->query($sql_tags);
// if ($res_tags && $res_tags->num_rows > 0) {
//     while ($linha = $res_tags->fetch_assoc()) {
//         echo '<span class="badge badge-secondary">' . htmlspecialchars($linha['nome']) . '</span> ';
//     }
// }

//EXIBIR NOTICIA COMPLETA

$sql = "SELECT * FROM noticias ORDER BY data_criacao DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $resumoCompleto = $row['resumo'];
    $resumoCorte = substr(strip_tags($resumoCompleto), 0, 150);

    echo '<div class="card mb-3">';
    echo '  <img src="' . $row['imagem'] . '" class="card-img-top" alt="Imagem da notícia">';
    echo '  <div class="card-body">';
    echo '    <h5 class="card-title">' . $row['titulo'] . '</h5>';
    echo '    <p class="card-text">' . substr(strip_tags($row['resumo']), 0, 100) . '...</p>';
    echo '    <button class="btn btn-primary toggle-btn" type="button" data-toggle="collapse" data-target="#noticia' . $row['id'] . '" aria-expanded="false" aria-controls="noticia' . $row['id'] . '">Ver mais</button>';
    echo '    <div class="collapse mt-3" id="noticia' . $row['id'] . '">';
    echo '      <div>' . $row['resumo'] . '</div>';
    echo '    </div>';
    echo '  </div>';
    echo '</div>';
    
  }
}
          ?>
        </section>

        <!-- Sidebar -->
        <aside class="col-lg-4 col-12 mb-4">
          <h4>Categorias</h4>
          <ul class="list-group mb-4">
            <li class="list-group-item"><a href="politica.php" class="text-dark">Política</a></li>
            <li class="list-group-item"><a href="esportes.php" class="text-dark">Esportes</a></li>
            <li class="list-group-item"><a href="tecnologia.php" class="text-dark">Tecnologia</a></li>
            <li class="list-group-item"><a href="economia.php" class="text-dark">Economia</a></li>
          </ul>

          <h4>Tags Populares</h4>
          <div class="mb-4">
            <span class="badge badge-secondary">#Eleições</span>
            <span class="badge badge-secondary">#Copa</span>
            <span class="badge badge-secondary">#Criptomoedas</span>
          </div>

          <h4>Newsletter</h4>
          <form>
          <input type="hidden" name="form_token" value="<?= $_SESSION['form_token'] ?>">

            <div class="form-group">
              <input type="email" class="form-control" placeholder="Seu e-mail">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Inscrever-se</button>
          </form>
        </aside>
      </div>
    </main>

    <!-- Rodapé -->
    <footer class="bg-dark text-white text-center py-3">
    <p class="mb-0">© 2025 Portal de Notícias — Todos os direitos reservados</p>
    <div class="mt-2">
        <a href="#" class="text-white mx-2">Facebook</a>
        <a href="#" class="text-white mx-2">Twitter</a>
        <a href="#" class="text-white mx-2">Instagram</a>
    </div>
</footer>

  </div>
</div>
<script>
  document.querySelectorAll('.btn-expandir').forEach(botao => {
    botao.addEventListener('click', () => {
      const card = botao.closest('.card-body');
      const resumoCurto = card.querySelector('.resumo-curto');
      const resumoCompleto = card.querySelector('.resumo-completo');

      resumoCurto.style.display = 'none';
      resumoCompleto.style.display = 'block';
      botao.style.display = 'none'; // esconde o botão depois de expandir
    });
  });
</script>
<script>
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const targetId = this.getAttribute('data-target');
      const target = document.querySelector(targetId);

      // Aguarda o Bootstrap terminar a animação (350ms por padrão)
      setTimeout(() => {
        if (target.classList.contains('show')) {
          this.textContent = 'Ver menos';
        } else {
          this.textContent = 'Ver mais';
        }
      }, 350);
    });
  });
</script>
<script>
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const targetId = this.getAttribute('data-target');
      const target = document.querySelector(targetId);

      // Aguarda o Bootstrap terminar a animação (350ms por padrão)
      setTimeout(() => {
        if (target.classList.contains('show')) {
          this.textContent = 'Ver menos';
        } else {
          this.textContent = 'Ver mais';
        }
      }, 350);
    });
  });
</script>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>

<?php $conn->close(); ?>
